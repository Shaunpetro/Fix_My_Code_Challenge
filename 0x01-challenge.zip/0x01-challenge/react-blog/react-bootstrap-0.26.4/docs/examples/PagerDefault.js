const pagerInstance = (
  <Pager>
    <PageItem href="#">Previous</PageItem>
    <PageItem href="#">Next</PageItem>
  </Pager>
);

React.render(pagerInstance, mountNode);
