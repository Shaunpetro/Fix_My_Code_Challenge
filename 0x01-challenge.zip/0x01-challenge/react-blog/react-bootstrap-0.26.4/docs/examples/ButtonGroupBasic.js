const buttonGroupInstance = (
  <ButtonGroup>
    <Button>Left</Button>
    <Button>Middle</Button>
    <Button>Right</Button>
  </ButtonGroup>
);

React.render(buttonGroupInstance, mountNode);
